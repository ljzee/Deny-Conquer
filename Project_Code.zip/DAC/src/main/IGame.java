package main;

import java.io.IOException;

public interface IGame {
    void run () throws IOException;
}
